//creating a diamond creeper variant, continuing in server scripts
EntityJSEvents.modifyEntity(event => {
    event.modify("minecraft:creeper", builder => {
        builder.defineSyncedData(entity => {
            entity.addSyncedData("string", "creeper_variant", "not_diamond")
        })
        builder.setTextureLocation(context => global.texture(context))
    })
})

global.texture = context => {
    let { entity } = context
    if (entity.getSyncedData("creeper_variant") == "diamond") {
        return `kubejs:textures/entity/variants/diamond_creeper.png`
    }
    return null
}
