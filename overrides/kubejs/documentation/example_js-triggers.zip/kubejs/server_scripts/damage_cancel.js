//disable type of damage (berry bush)
let $DamageTypes = Java.loadClass("net.minecraft.world.damagesource.DamageTypes");

EntityEvents.hurt('minecraft:player', e => {
    if (e.source.is($DamageTypes.SWEET_BERRY_BUSH)) {
        e.cancel();
    }
}