// Listen to item tag event
ServerEvents.tags('item', event => {
  event.add('minecraft:mineable/axe', 'recrafted_creatures:stick_bundle')
  event.add('minecraft:mineable/shovel', 'recrafted_creatures:muddy_stick_bundle')
})