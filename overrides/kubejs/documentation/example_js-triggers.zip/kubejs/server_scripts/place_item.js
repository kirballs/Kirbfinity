//place an item like a block
ItemEvents.rightClicked('modid:example_item', event => {
  let thisBlock = event.target.block

    //check all nearby blocks
  if (!thisBlock.hasTag('minecraft:replaceable')){
    switch (event.target.facing) {
      case 'UP':
        thisBlock = event.target.block.up
        break;
      case 'DOWN':
        thisBlock = event.target.block.down
        break;
      case 'NORTH':
        thisBlock = event.target.block.north
        break;
      case 'SOUTH':
        thisBlock = event.target.block.south
        break;
      case 'EAST':
        thisBlock = event.target.block.east
        break;
      case 'WEST':
        thisBlock = event.target.block.west
        break;
      }
    }
  //disallow placing above air
  if (thisBlock.down.hasTag('minecraft:replaceable')) {return}

  if (thisBlock.hasTag('minecraft:replaceable'))
    {
    //play a block placing sound
    event.level.runCommandSilent(`/execute positioned ${thisBlock.pos.x} ${thisBlock.pos.y} ${thisBlock.pos.z} run playsound YOUR_BLOCK_PLACING_SOUND block @a`)
        
    //set the block in the world
    thisBlock.set('YOUR_BLOCK')

    //reduce the stack size in player's hand
    event.item.count--
    }
})