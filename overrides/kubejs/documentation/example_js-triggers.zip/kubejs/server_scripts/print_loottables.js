//print chests loot tables in "chests" folder
ServerEvents.highPriorityData(event => {
    const $LootDataType = Java.loadClass(
        'net.minecraft.world.level.storage.loot.LootDataType'
    )

    console.log("[KubeJS] highPriorityData START")
    let lootData = Utils.server.getLootData()
    let allTables = lootData.getKeys($LootDataType.TABLE)
    console.log("[KubeJS] LootTables gesamt: " + allTables.size())
    let chestTables = allTables.stream()
        .filter(id => id.path.contains("chests"))
        .map(id => id.toString())
        .toList()
    console.log("[KubeJS] Chest LootTables: " + chestTables.size())
    JsonIO.write("kubejs/chests/lootTables.json", {
        chest_loot_tables: chestTables
    })
    console.log("[KubeJS] lootTables.json geschrieben")
})