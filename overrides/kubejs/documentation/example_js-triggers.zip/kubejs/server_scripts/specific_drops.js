//make mobs drop certain items when killed eith certain weapons
let Weapons = [
    "minecraft:diamond_sword",
    "minecraft:netherite_sword",
];
LootJS.modifiers((event) => {
    const corpseloot = LootEntry.of("minecraft:emerald").when(c =>
        c.matchMainHand(Weapons)
    )
    event
        .addEntityLootModifier("minecraft:villager")
        .addSequenceLoot(corpseloot)
})