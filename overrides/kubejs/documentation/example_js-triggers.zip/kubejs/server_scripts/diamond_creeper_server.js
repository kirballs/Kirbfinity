let DiamondCreeperChance = 50

function IsDiamond(uuid) {
    if (DiamondCreeperChance <= 0) return false;
    
    let uuidStr = uuid.toString().replace(/-/g, '')
    let mostSignificantHex = uuidStr.substring(0, 16)
    
    let most = parseInt(mostSignificantHex.substring(8), 16)
    
    return most % DiamondCreeperChance === 0;
}

EntityEvents.spawned(event => {
    let entity = event.entity

    if (entity.type == "minecraft:creeper") {   
        if (IsDiamond(entity.uuid)) {
            //our custom data
            entity.setSyncedData("creeper_variant", "diamond")
            
            //entity nbt
            event.entity.mergeNbt({ ExplosionRadius: 5 })
            
            //attributes
            entity.modifyAttribute("generic.movement_speed","more_speed_id", 0.1, "addition")
            
            //health
            entity.modifyAttribute("generic.max_health","more_health_id", 10, "addition")
            //heal to max health
            entity.setHealth(entity.maxHealth)
            
            //how to do a potion effect
            //entity.potionEffects.add("minecraft:regeneration", 99999, 1, true, false);
            
            console.log(`Diamond Creeper spawned with UUID: ${entity.uuid.toString()}`)
        }
    }
})


//custom drops
EntityEvents.drops("minecraft:creeper", event => {
    if (event.entity.getSyncedData("creeper_variant") == "diamond") {
        event.addDrop("minecraft:diamond")
    }
})
