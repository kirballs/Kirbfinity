JEIEvents.hideItems(event => {
    
    for (const item of global.hideList) {
        event.hide(item)
    }
    
})